package com.demo.kinshademo3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KinshaDemo3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
