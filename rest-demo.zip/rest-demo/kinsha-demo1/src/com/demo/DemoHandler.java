package com.demo;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Path("/demo")
public class DemoHandler {

	@GET
	@Path("/welcome")
	public String welcome() {
		return "Welcome to Kinsha Demo";
	}
}
